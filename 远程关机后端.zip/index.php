<?php
// 连接redis
// redis是一个内存数据库
// k 对 v那种
$redis = new Redis();
$redis->connect('127.0.0.1', 6379);

// 如果锁存在
if ($redis->get('shutdown_lock')) {
    exit('1关机2');
} else {
    exit('1开机2');
}