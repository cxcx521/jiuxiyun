<?php

// 延迟秒
$m = 10; // 秒


$redis = new Redis();
$redis->connect('127.0.0.1', 6379);
// 获取get参数为ext
$ext = $_GET['ext'] ?? false;

// 判断是否输入
if(!isset($ext) || !$ext || $ext == '') {
    // 停止应用 输出空
    exit('');
}
// 如果关机
if ($ext == 'true') {
    // 写入redis 锁  2秒自动删除
    $redis->set('shutdown_lock','1',$m);
}
 //玖曦云计算提供技术支持
 //玖曦云计算jiuxiyun.cn
 //远程关机配置文件
 
 
 
 
 
 
 
?>